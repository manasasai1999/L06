/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package L05;

import javax.swing.JPanel;
/**
 *
 * @author user
 */
public class CenterPanel extends JPanel
{
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    CenterPanel(Group grp)
    {
        jButton4 = new javax.swing.JButton();        
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();

        setLayout(new java.awt.GridLayout(4, 0));
        jButton4.setText(grp.member1.getInfo());
        add(jButton4);

        jButton5.setText(grp.member2.getInfo());
        add(jButton5);

        jButton6.setText(grp.member3.getInfo());
        add(jButton6);

        jButton7.setText(grp.member4.getInfo());
        add(jButton7);
    }
}
