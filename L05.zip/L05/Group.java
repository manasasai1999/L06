/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package L05;

/**
 *
 * @author user
 */
public class Group 
{
    public String name;
    public Student member1;
    public Student member2;
    public Student member3;
    public Student member4;

    public Group(String name, Student s1, Student s2, Student s3, Student s4) 
    {

        this.name=name;
        this.member1=s1;
        this.member2=s2;
        this.member3=s3;
        this.member4=s4;

    
    }
    public void getInfo() 
   {

        System.out.printf("Group Name: %s\n",this.name);

        this.member1.getInfo();
        this.member2.getInfo();
        this.member3.getInfo();
        this.member4.getInfo();

        System.out.printf("Group GPA: %.2f\n",this.averageGPA());

   }

   public Double averageGPA() 
   {

        double avgGPA=0.0;
        avgGPA=this.member1.getGPA()+this.member2.getGPA()+this.member3.getGPA()+this.member4.getGPA();
        avgGPA/=4;
        long factor = (long) Math.pow(10, 2);
        avgGPA = avgGPA * factor;
        long tmp = Math.round(avgGPA);
        return (double) tmp / factor;
//        return avgGPA;

   }
   
   public double getSemesterGPA(Student s) 
   {
        return s.getGPA();
   }
   
}
