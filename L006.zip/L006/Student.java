/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package L006;

public class Student {
	
    private String firstName, lastName;
    private int age;
    private double gpa;

    public Student(String firstName, String lastName, int age) {
           this.firstName = firstName;
           this.lastName = lastName;
           this.age = age;

           //initialise GPA
           semesterGPA();
   }
    
    public void semesterGPA() {
         double semgpa = Math.random() * 4.0;
         long factor = (long) Math.pow(10, 2);
         semgpa = semgpa * factor;
         long tmp = Math.round(semgpa);
         gpa=(double) tmp / factor;
    }

   public String getInfo() {
        return "Name = " +this.firstName+" "+this.lastName+" "+this.gpa;
   }
   
   public double getGPA() {
        return gpa;
   }

   public String getFirstName() {
        return firstName;
   }
}