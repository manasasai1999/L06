/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package L006;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JPanel;

public abstract class ControlPanel extends JPanel implements ActionListener{
	
    private JButton jButton8, jButton9, jButton10, jButton11;
    private TopPanel topPanel;
    private CenterPanel centerPanel;
    
    ControlPanel(Group grp) {
        topPanel = new TopPanel(grp);
        topPanel.setBackground(new java.awt.Color(0, 0, 204));
        topPanel.setPreferredSize(new java.awt.Dimension(590, 45));
        
        centerPanel = new CenterPanel(grp,topPanel) {
            public void actionPerformed(ActionEvent e) {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        };
        centerPanel.setLayout(new java.awt.GridLayout(4, 0));
        
        setLayout(new java.awt.BorderLayout(1, 1));
        add(topPanel, java.awt.BorderLayout.PAGE_START);
        add(centerPanel, java.awt.BorderLayout.CENTER);
    }
    
    ControlPanel(Group grp, TopPanel topPanel, CenterPanel centerPanel) {
        topPanel = new TopPanel(grp);
        topPanel.setBackground(new java.awt.Color(0, 0, 204));
        topPanel.setPreferredSize(new java.awt.Dimension(590, 45));
        
        centerPanel = new CenterPanel(grp,topPanel) 
        {
            public void actionPerformed(ActionEvent e) 
            {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        };
        centerPanel.setLayout(new java.awt.GridLayout(4, 0));
        add(topPanel, java.awt.BorderLayout.PAGE_START);
        add(centerPanel, java.awt.BorderLayout.CENTER);

        setLayout(new java.awt.BorderLayout(1, 1));
        initButtons(grp, topPanel);
    }
    
    public void initButtons(Group grp, TopPanel topPanel) {
    	jButton8 = new JButton(); 
        jButton8.addActionListener(new ActionListener(){
          public void actionPerformed(ActionEvent e)
          {
            grp.member1.semesterGPA();
            jButton8.setText(grp.member1.getInfo());
            topPanel.getavgGPAButton().setText(grp.averageGPA().toString());
          }
        });
        
        jButton9 = new JButton();
        jButton9.addActionListener(new ActionListener(){
          public void actionPerformed(ActionEvent e)
          {
            grp.member2.semesterGPA();
            jButton9.setText(grp.member2.getInfo());
            topPanel.getavgGPAButton().setText(grp.averageGPA().toString());
          }
        });
        
        jButton10 = new JButton();
        jButton10.addActionListener(new ActionListener(){
          public void actionPerformed(ActionEvent e)
          {
            grp.member3.semesterGPA();
            jButton10.setText(grp.member3.getInfo());
            topPanel.getavgGPAButton().setText(grp.averageGPA().toString());
          }
        });
        
        jButton11 = new JButton();
        jButton11.addActionListener(new ActionListener(){
          public void actionPerformed(ActionEvent e)
          {
            grp.member4.semesterGPA();
            jButton11.setText(grp.member4.getInfo());
            topPanel.getavgGPAButton().setText(grp.averageGPA().toString());
          }
        });

        setLayout(new java.awt.GridLayout(4, 0));
        jButton8.setText(grp.member1.getInfo());
        add(jButton8);

        jButton9.setText(grp.member2.getInfo());
        add(jButton9);

        jButton10.setText(grp.member3.getInfo());
        add(jButton10);

        jButton11.setText(grp.member4.getInfo());
        add(jButton11);
    }
}