/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package L006;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JPanel;

public abstract class CenterPanel extends JPanel 
{
	
    public JButton jButton4, jButton5, jButton6, jButton7;
    
    CenterPanel(Group grp, TopPanel topPanel) 
    {   
        jButton4 = new JButton(); 
        jButton4.addActionListener(new ActionListener(){
          public void actionPerformed(ActionEvent e)
          {
            grp.member1.semesterGPA();
            jButton4.setText(grp.member1.getInfo());
            topPanel.getavgGPAButton().setText(grp.averageGPA().toString());
          }
        });
        
        jButton5 = new JButton();
        jButton5.addActionListener(new ActionListener(){
          public void actionPerformed(ActionEvent e)
          {
            grp.member2.semesterGPA();
            jButton5.setText(grp.member2.getInfo());
            topPanel.getavgGPAButton().setText(grp.averageGPA().toString());
          }
        });
        
        jButton6 = new JButton();
        jButton6.addActionListener(new ActionListener(){
          public void actionPerformed(ActionEvent e)
          {
            grp.member3.semesterGPA();
            jButton6.setText(grp.member3.getInfo());
            topPanel.getavgGPAButton().setText(grp.averageGPA().toString());
          }
        });
        
        jButton7 = new JButton();
        jButton7.addActionListener(new ActionListener(){
          public void actionPerformed(ActionEvent e)
          {
            grp.member4.semesterGPA();
            jButton7.setText(grp.member4.getInfo());
            topPanel.getavgGPAButton().setText(grp.averageGPA().toString());
          }
        });

        setLayout(new GridLayout(4, 0));
        jButton4.setText(grp.member1.getInfo());
        add(jButton4);

        jButton5.setText(grp.member2.getInfo());
        add(jButton5);

        jButton6.setText(grp.member3.getInfo());
        add(jButton6);

        jButton7.setText(grp.member4.getInfo());
        add(jButton7);
    }
}