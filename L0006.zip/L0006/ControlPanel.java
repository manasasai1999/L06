/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package L0006;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JPanel;

public abstract class ControlPanel extends JPanel implements ActionListener{
	
    private JButton jButton8, jButton9, jButton10, jButton11;
    private TopPanel topPanel;
    private JPanel buttonPanel;
    
    ControlPanel(Group grp, TopPanel topPanel) {
        topPanel = new TopPanel(grp);
        topPanel.setBackground(new Color(0, 0, 204));
        topPanel.setPreferredSize(new Dimension(590, 45));
        
        setLayout(new GridLayout(2,1));
        add(topPanel);
        initButtons(grp, topPanel);
    }
    
    public void initButtons(Group grp, TopPanel topPanel) {
    	jButton8 = new JButton(); 
        jButton8.addActionListener(new ActionListener(){
          public void actionPerformed(ActionEvent e)
          {
            grp.member1.semesterGPA();
            jButton8.setText(grp.member1.getInfo());
            topPanel.getavgGPAButton().setText(grp.averageGPA().toString());
          }
        });
        
        jButton9 = new JButton();
        jButton9.addActionListener(new ActionListener(){
          public void actionPerformed(ActionEvent e)
          {
            grp.member2.semesterGPA();
            jButton9.setText(grp.member2.getInfo());
            topPanel.getavgGPAButton().setText(grp.averageGPA().toString());
          }
        });
        
        jButton10 = new JButton();
        jButton10.addActionListener(new ActionListener(){
          public void actionPerformed(ActionEvent e)
          {
            grp.member3.semesterGPA();
            jButton10.setText(grp.member3.getInfo());
            topPanel.getavgGPAButton().setText(grp.averageGPA().toString());
          }
        });
        
        jButton11 = new JButton();
        jButton11.addActionListener(new ActionListener(){
          public void actionPerformed(ActionEvent e)
          {
            grp.member4.semesterGPA();
            jButton11.setText(grp.member4.getInfo());
            topPanel.getavgGPAButton().setText(grp.averageGPA().toString());
          }
        });
        
        buttonPanel = new JPanel();
        buttonPanel.setLayout(new java.awt.GridLayout(4,0));
        jButton8.setText(grp.member1.getInfo());
        buttonPanel.add(jButton8);

        jButton9.setText(grp.member2.getInfo());
        buttonPanel.add(jButton9);

        jButton10.setText(grp.member3.getInfo());
        buttonPanel.add(jButton10);

        jButton11.setText(grp.member4.getInfo());
        buttonPanel.add(jButton11);
        
        this.add(buttonPanel);
    }
}